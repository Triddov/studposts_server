create function changelikescount() returns trigger
    language plpgsql
as
$$
        BEGIN
            IF (TG_OP = 'DELETE') THEN
                UPDATE posts
                SET likesCount = (SELECT COUNT(*) FROM likes WHERE post_id = OLD.post_id)
                WHERE unique_id = OLD.post_id;
                
                DELETE FROM dislikes WHERE post_id = OLD.post_id and owner_login = OLD.owner_login;
                
                
            ELSIF (TG_OP = 'INSERT') THEN
                UPDATE posts
                SET likesCount = (SELECT COUNT(*) FROM likes WHERE post_id = NEW.post_id)
                WHERE unique_id = NEW.post_id; 
                
                DELETE FROM dislikes WHERE post_id = NEW.post_id and owner_login = NEW.owner_login;
            END IF;
            RETURN NULL;
        END;
        $$;

alter function changelikescount() owner to postgres;

