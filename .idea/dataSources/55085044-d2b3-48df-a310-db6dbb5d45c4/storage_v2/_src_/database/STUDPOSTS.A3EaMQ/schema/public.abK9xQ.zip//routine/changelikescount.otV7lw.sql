create function changelikescount() returns trigger
    language plpgsql
as
$$
        BEGIN
            IF (TG_OP = 'DELETE') THEN
                UPDATE posts
                SET likesCount = (SELECT COUNT(*) FROM likes WHERE post_id = OLD.post_id)
                WHERE unique_id = OLD.post_id;
            ELSIF (TG_OP = 'INSERT') THEN
                UPDATE posts
                SET likesCount = (SELECT COUNT(*) FROM likes WHERE post_id = NEW.post_id)
                WHERE unique_id = NEW.post_id; 
            END IF;
            RETURN NULL;
        END;
        $$;

alter function changelikescount() owner to postgres;

